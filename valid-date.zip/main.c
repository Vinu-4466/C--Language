
#include <stdio.h>

int main()
{
    
#include <stdio.h>

int main()
{
    int day, month, year;
    printf("entered date (dd//mm//yr):");
    scanf("%d/%d/%d",&day ,&month ,&year);
    if (year>0 && month>1 && month <=12 && day>1 && day<=31){
        
    }
    
    return 0;
}


    return 0;
}
