
#include <stdio.h>

int main()
{
    if(printf(" "))
    {
        printf("ICE");
    }
    else
    {
        printf("CREAM");
    }

    return 0;
}
